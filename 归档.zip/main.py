def main():
    print("Hello from new-stat!")


if __name__ == "__main__":
    main()
